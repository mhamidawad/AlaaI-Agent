"""Code generation components."""

from .code_generator import CodeGenerator

__all__ = ["CodeGenerator"]